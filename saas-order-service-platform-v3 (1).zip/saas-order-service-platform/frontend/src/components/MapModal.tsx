import React from "react";
import { MapContainer, TileLayer, Marker, Polyline } from "react-leaflet";
import L from "leaflet";
import { motion, AnimatePresence } from "framer-motion";
import { X } from "lucide-react";
import { Button } from "./Button";

// Fix default marker icon paths for bundlers
import markerIcon2x from "leaflet/dist/images/marker-icon-2x.png";
import markerIcon from "leaflet/dist/images/marker-icon.png";
import markerShadow from "leaflet/dist/images/marker-shadow.png";

L.Icon.Default.mergeOptions({
  iconRetinaUrl: markerIcon2x,
  iconUrl: markerIcon,
  shadowUrl: markerShadow,
});

type LatLng = { lat: number; lng: number };

async function fetchRoute(from: LatLng, to: LatLng): Promise<[number, number][]> {
  const url = `https://router.project-osrm.org/route/v1/driving/${from.lng},${from.lat};${to.lng},${to.lat}?overview=full&geometries=geojson`;
  const r = await fetch(url);
  if (!r.ok) throw new Error("Route fetch failed");
  const data = await r.json();
  const coords = data?.routes?.[0]?.geometry?.coordinates ?? [];
  // OSRM returns [lng,lat]
  return coords.map((c: [number, number]) => [c[1], c[0]]);
}

export function MapModal({
  open,
  onClose,
  current,
  destination,
}: {
  open: boolean;
  onClose: () => void;
  current?: LatLng | null;
  destination?: LatLng | null;
}) {
  const [route, setRoute] = React.useState<[number, number][]>([]);
  const [err, setErr] = React.useState<string | null>(null);

  React.useEffect(() => {
    let alive = true;
    setErr(null);
    setRoute([]);
    (async () => {
      if (!open) return;
      if (!current || !destination) return;
      try {
        const pts = await fetchRoute(current, destination);
        if (alive) setRoute(pts);
      } catch (e: any) {
        if (alive) setErr(e?.message || "Route error");
      }
    })();
    return () => { alive = false; };
  }, [open, current?.lat, current?.lng, destination?.lat, destination?.lng]);

  const center: [number, number] = current ? [current.lat, current.lng] : (destination ? [destination.lat, destination.lng] : [20.5937, 78.9629]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div className="fixed inset-0 z-50"
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
          <motion.div
            initial={{ opacity: 0, y: 12, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.98 }}
            transition={{ duration: 0.25 }}
            className="absolute inset-x-3 top-10 bottom-10 md:inset-x-10 rounded-3xl border border-white/12 bg-[#070a16] shadow-glow overflow-hidden"
          >
            <div className="flex items-center justify-between px-4 py-3 border-b border-white/10 bg-black/20">
              <div>
                <div className="text-sm font-semibold">Live Delivery Map</div>
                <div className="text-xs text-white/55">Real-time marker + route path</div>
              </div>
              <Button variant="ghost" onClick={onClose} className="flex items-center gap-2">
                <X size={16} /> Close
              </Button>
            </div>

            <div className="h-full">
              <MapContainer center={center} zoom={13} style={{ height: "100%", width: "100%" }}>
                <TileLayer
                  attribution='&copy; OpenStreetMap contributors'
                  url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                />
                {current && <Marker position={[current.lat, current.lng]} />}
                {destination && <Marker position={[destination.lat, destination.lng]} />}
                {route.length > 0 && <Polyline positions={route} />}
              </MapContainer>
            </div>

            {( !current || !destination) && (
              <div className="absolute left-4 bottom-4 right-4 rounded-2xl border border-white/12 bg-black/40 p-3 text-xs text-white/70">
                Tip: Set destination (Admin/Manager) and start GPS (Delivery) to see route.
              </div>
            )}
            {err && (
              <div className="absolute left-4 bottom-4 right-4 rounded-2xl border border-red-500/30 bg-red-500/10 p-3 text-xs text-red-200">
                {err}
              </div>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
